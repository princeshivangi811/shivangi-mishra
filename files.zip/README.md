<div align="center">

# 🏦 Loan Approval Process — Business Analysis & Optimization

**A business process re-engineering case study: diagnosing workflow bottlenecks and redesigning for a 57% reduction in turnaround time**

![Status](https://img.shields.io/badge/status-complete-2E8B57?style=flat-square)
![Type](https://img.shields.io/badge/type-case%20study-2C3E50?style=flat-square)
![Tools](https://img.shields.io/badge/tools-BRD%20%7C%20Process%20Mapping%20%7C%20Gap%20Analysis-EAA221?style=flat-square)

</div>

---

## 📌 Problem Statement

A bank's personal loan approval process takes an average of **7 business days** to complete. Applicants experience long, opaque wait times, and internal teams face rework driven by inconsistent underwriting decisions. This project analyzes the current process end-to-end, isolates the root causes of delay, and proposes a redesigned workflow with a quantified, defensible business case for change.

---

## 🧭 My Approach

As the Business Analyst on this initiative, I followed a structured BA lifecycle:

| Step | Activity |
|:---:|---|
| **1. Elicit** | Mapped the current (AS-IS) workflow and surfaced stakeholder pain points |
| **2. Analyze** | Performed gap and root-cause analysis to isolate sources of delay |
| **3. Document** | Authored a formal Business Requirements Document (BRD) |
| **4. Design** | Proposed a future-state (TO-BE) process built around automation and parallel processing |
| **5. Recommend** | Quantified the expected impact to support a business decision |

---

## 🔍 Key Findings

- Document verification and credit bureau checks run **sequentially**, not in parallel
- Manual, paper-based document review adds **~2 days** per application
- No standardized risk-scoring tool — underwriting decisions vary by reviewer
- Applicants have **no real-time visibility** into application status

## ✅ Proposed Solution & Impact

Redesigning the workflow to run document verification and credit checks **in parallel**, backed by OCR-based automation and a standardized risk score, is projected to cut average approval time from **7 days → 3 days**.

<div align="center">

### ⏱️ ~57% reduction in turnaround time

</div>

---

## 🗺️ Process Maps

<table>
<tr>
<td align="center"><b>AS-IS — Current State</b></td>
<td align="center"><b>TO-BE — Future State</b></td>
</tr>
<tr>
<td><img src="AS-IS_Process_Map.png" width="420"></td>
<td><img src="TO-BE_Process_Map.png" width="420"></td>
</tr>
</table>

---

## 📁 Repository Contents

| File | Description |
|---|---|
| [`BRD_Loan_Approval_Process.docx`](BRD_Loan_Approval_Process.docx) | Full Business Requirements Document — objectives, stakeholders, functional & non-functional requirements, success metrics |
| [`AS-IS_Process_Map.svg`](AS-IS_Process_Map.svg) / `.png` | Current-state workflow diagram with bottlenecks highlighted |
| [`TO-BE_Process_Map.svg`](TO-BE_Process_Map.svg) / `.png` | Proposed future-state workflow diagram |

---

## 🛠️ Skills Demonstrated

`Business Process Mapping`  `Requirements Documentation (BRD)`  `Stakeholder Analysis`  `Gap & Root-Cause Analysis`  `Process Optimization`  `Data-Driven Recommendations`

---

## 🔭 Next Steps

- Validate assumptions with a Power BI dashboard built on a public loan dataset (approval rates, turnaround time by segment)
- Add a formal Gap Analysis worksheet and RACI matrix for implementation planning

---

<div align="center">
<sub>Prepared by Shivangi Mishra · Business Analyst</sub>
</div>
